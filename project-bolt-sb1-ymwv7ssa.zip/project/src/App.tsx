import React, { useState } from 'react';
import { FileText, IndianRupee } from 'lucide-react';

type ServiceCategory = 'video' | 'web' | 'app' | 'ai' | 'design';
type PaymentOption = '10' | '50' | '100';

interface FormData {
  prompt: string;
  type: string;
  subtype: string;
  frequency: string;
  length: string;
  description: string;
  paymentOption: PaymentOption;
}

function App() {
  const [formData, setFormData] = useState<FormData>({
    prompt: '',
    type: '',
    subtype: '',
    frequency: '',
    length: '',
    description: '',
    paymentOption: '10'
  });

  const [tags, setTags] = useState<string[]>([]);
  const [orderNumber] = useState(`ORD${Math.floor(Math.random() * 10000)}`);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const addTag = (tag: string) => {
    if (!tags.includes(tag)) {
      setTags([...tags, tag]);
    }
  };

  const removeTag = (tagToRemove: string) => {
    setTags(tags.filter(tag => tag !== tagToRemove));
  };

  const getDeliveryDays = (option: PaymentOption) => {
    switch (option) {
      case '10': return '3 Days';
      case '50': return '2 Days';
      case '100': return '1 Day';
      default: return '3 Days';
    }
  };

  return (
    <div className="min-h-screen bg-[#1a1f2e] text-gray-200">
      {/* Header */}
      <header className="p-6 flex justify-between items-center">
        <h1 className="text-2xl font-bold">krip.ai</h1>
        <nav className="space-x-6">
          <a href="#" className="hover:text-white">Home</a>
          <a href="#" className="hover:text-white">About</a>
          <a href="#" className="bg-red-500 px-4 py-2 rounded-full hover:bg-red-600">Contact Us</a>
        </nav>
      </header>

      {/* Main Content */}
      <div className="container mx-auto p-6 grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Payment Details */}
        <div className="space-y-8">
          <div className="bg-[#232936] rounded-lg p-6 space-y-6">
            <h2 className="text-xl font-semibold text-[#3b9ae2]">Payment Details</h2>
            
            <div className="border-b border-gray-700 pb-4">
              <div className="flex justify-between items-center">
                <span>Total Price</span>
                <span className="text-xl">Rs. 1000</span>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-lg font-medium">Delivery Details</h3>
              <div className="flex justify-between items-center border-b border-gray-700 pb-4">
                <span>Estimated Time of Delivery</span>
                <span>{getDeliveryDays(formData.paymentOption)}</span>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-lg font-medium">Select Your Preferred Payment Options</h3>
              <div className="space-y-3">
                <label className="flex items-center space-x-3">
                  <input
                    type="radio"
                    name="paymentOption"
                    value="10"
                    checked={formData.paymentOption === '10'}
                    onChange={handleInputChange}
                    className="form-radio text-blue-500"
                  />
                  <span>10% (Upfront Pay) + 40%(Pay Mid-way) + 50%(Pay by Delivery)</span>
                  <span className="text-sm text-gray-400">3 Days Delivery</span>
                </label>
                <label className="flex items-center space-x-3">
                  <input
                    type="radio"
                    name="paymentOption"
                    value="50"
                    checked={formData.paymentOption === '50'}
                    onChange={handleInputChange}
                    className="form-radio text-blue-500"
                  />
                  <span>50% (Upfront Pay) + 50%(Pay by Delivery)</span>
                  <span className="text-sm text-gray-400">2 Days Delivery</span>
                </label>
                <label className="flex items-center space-x-3">
                  <input
                    type="radio"
                    name="paymentOption"
                    value="100"
                    checked={formData.paymentOption === '100'}
                    onChange={handleInputChange}
                    className="form-radio text-blue-500"
                  />
                  <span>100%(Pay by Delivery)</span>
                  <span className="text-sm text-gray-400">1 Day Delivery</span>
                </label>
              </div>
            </div>

            <button className="w-full bg-blue-500 text-white py-3 rounded-lg hover:bg-blue-600 transition-colors">
              Place Order
            </button>
          </div>
        </div>

        {/* Specsheet */}
        <div className="bg-[#232936] rounded-lg p-6">
          <h2 className="text-2xl font-bold mb-6">SPECSHEET</h2>
          <p className="text-sm text-gray-400 mb-6">
            This sheet has all the scope of work listed below based on the questions you answered
          </p>

          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-medium mb-4">Scope of Work</h3>
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-2">
                  <span className="text-gray-400">Prompt</span>
                  <input
                    type="text"
                    name="prompt"
                    value={formData.prompt}
                    onChange={handleInputChange}
                    className="bg-transparent border-b border-gray-700 focus:outline-none"
                    placeholder="Video editor for instagram"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <span className="text-gray-400">Type of video</span>
                  <input
                    type="text"
                    name="type"
                    value={formData.type}
                    onChange={handleInputChange}
                    className="bg-transparent border-b border-gray-700 focus:outline-none"
                    placeholder="Infotainment reel"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <span className="text-gray-400">Subtype of video</span>
                  <input
                    type="text"
                    name="subtype"
                    value={formData.subtype}
                    onChange={handleInputChange}
                    className="bg-transparent border-b border-gray-700 focus:outline-none"
                    placeholder="Velocity edit"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <span className="text-gray-400">Frequency of video</span>
                  <input
                    type="text"
                    name="frequency"
                    value={formData.frequency}
                    onChange={handleInputChange}
                    className="bg-transparent border-b border-gray-700 focus:outline-none"
                    placeholder="Recurring videos"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <span className="text-gray-400">Length of video</span>
                  <input
                    type="text"
                    name="length"
                    value={formData.length}
                    onChange={handleInputChange}
                    className="bg-transparent border-b border-gray-700 focus:outline-none"
                    placeholder="30-60 seconds"
                  />
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-medium mb-4">Descriptive</h3>
              <textarea
                name="description"
                value={formData.description}
                onChange={handleInputChange}
                className="w-full bg-[#1a1f2e] rounded-lg p-3 min-h-[100px] focus:outline-none"
                placeholder="The video editing project will involve transforming raw footage into engaging and informative reels. By skillfully combining storytelling, visual effects, and audio elements."
              />
            </div>

            <div>
              <h3 className="text-lg font-medium mb-4">Tags</h3>
              <div className="flex flex-wrap gap-2">
                {tags.map(tag => (
                  <span
                    key={tag}
                    className="bg-[#1a1f2e] px-3 py-1 rounded-full text-sm flex items-center gap-2"
                  >
                    {tag}
                    <button
                      onClick={() => removeTag(tag)}
                      className="text-gray-400 hover:text-white"
                    >
                      ×
                    </button>
                  </span>
                ))}
                <button
                  onClick={() => addTag('Motion Graphics')}
                  className="bg-[#1a1f2e] px-3 py-1 rounded-full text-sm hover:bg-gray-700"
                >
                  + Add Tag
                </button>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-medium mb-4">Order Details</h3>
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-2">
                  <span className="text-gray-400">Order Number</span>
                  <span>{orderNumber}</span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <span className="text-gray-400">Order Date</span>
                  <span>{new Date().toLocaleDateString()}</span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <span className="text-gray-400">Invoice Details</span>
                  <span>Pending</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;